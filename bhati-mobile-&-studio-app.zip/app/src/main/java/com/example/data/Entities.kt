package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "products")
data class Product(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val category: String, // "Smartphones" or "Accessories"
    val price: Double,
    val description: String,
    val imageUrl: String = "",
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "studio_services")
data class StudioService(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val name: String,
    val type: String, // "Photography", "Editing", "Packages"
    val price: Double,
    val description: String,
    val timestamp: Long = System.currentTimeMillis()
)
