package com.example.data

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first

class ShopRepository(private val shopDao: ShopDao) {

    val allProducts: Flow<List<Product>> = shopDao.getAllProducts()
    val allServices: Flow<List<StudioService>> = shopDao.getAllServices()

    suspend fun insertProduct(product: Product) = shopDao.insertProduct(product)
    suspend fun updateProduct(product: Product) = shopDao.updateProduct(product)
    suspend fun deleteProduct(product: Product) = shopDao.deleteProduct(product)
    suspend fun deleteProductById(id: Int) = shopDao.deleteProductById(id)

    suspend fun insertService(service: StudioService) = shopDao.insertService(service)
    suspend fun updateService(service: StudioService) = shopDao.updateService(service)
    suspend fun deleteService(service: StudioService) = shopDao.deleteService(service)
    suspend fun deleteServiceById(id: Int) = shopDao.deleteServiceById(id)

    suspend fun prepopulateIfEmpty() {
        // Prepopulate Products if empty
        val currentProducts = allProducts.first()
        if (currentProducts.isEmpty()) {
            val defaultProducts = listOf(
                Product(
                    name = "Samsung Galaxy A15 5G",
                    category = "Smartphones",
                    price = 15499.0,
                    description = "8GB RAM, 128GB Storage, Super AMOLED 90Hz Display, 50MP Triple Camera, 5000mAh Battery."
                ),
                Product(
                    name = "Redmi Note 13 5G",
                    category = "Smartphones",
                    price = 13999.0,
                    description = "6GB RAM, 128GB Storage, 108MP Ultra-clear Camera, Super-slim design, 120Hz AMOLED Screen."
                ),
                Product(
                    name = "OnePlus Nord CE4 Lite",
                    category = "Smartphones",
                    price = 19999.0,
                    description = "8GB RAM, 128GB Storage, 80W SUPERVOOC Fast Charge, Sony LYT-600 Camera, Dual Stereo Speakers."
                ),
                Product(
                    name = "boAt Rockerz 255 Pro+",
                    category = "Accessories",
                    price = 1299.0,
                    description = "Wireless Bluetooth Neckband with ASAP Charge, up to 40 Hours Playback, IPX7 Water & Sweat Resistance."
                ),
                Product(
                    name = "Mi 33W SonicCharge 2.0",
                    category = "Accessories",
                    price = 899.0,
                    description = "Super-fast wall charger with Qualcomm Quick Charge 3.0 support, includes high-speed Type-C cable."
                ),
                Product(
                    name = "Premium Liquid Silicon Case",
                    category = "Accessories",
                    price = 299.0,
                    description = "Ultra-protective shockproof case with soft microfiber lining, camera protection. Available for all models."
                ),
                Product(
                    name = "9H Matte Tempered Glass",
                    category = "Accessories",
                    price = 199.0,
                    description = "Premium anti-glare screen protector with full glue edge-to-edge coverage and oil/scratch resistance."
                )
            )
            for (p in defaultProducts) {
                shopDao.insertProduct(p)
            }
        }

        // Prepopulate Services if empty
        val currentServices = allServices.first()
        if (currentServices.isEmpty()) {
            val defaultServices = listOf(
                StudioService(
                    name = "Instant Passport Size Photos",
                    type = "Photography",
                    price = 80.0,
                    description = "8 professional glossy passport size photos printed in just 5 minutes with optional white/blue background."
                ),
                StudioService(
                    name = "Professional Photo Editing",
                    type = "Editing",
                    price = 150.0,
                    description = "Background removal, face retouching, color enhancement, and custom sizing for official or casual photos."
                ),
                StudioService(
                    name = "Cinematic Video Editing",
                    type = "Editing",
                    price = 1500.0,
                    description = "High-quality video post-processing, transitions, sound effects, audio mixing, and stabilization for reels/vlogs."
                ),
                StudioService(
                    name = "Wedding Photography & Videography",
                    type = "Packages",
                    price = 25000.0,
                    description = "Complete wedding day coverage by expert photographers, cinematic highlight video, and custom printed photo book."
                ),
                StudioService(
                    name = "Pre-Wedding Outdoor Shoot",
                    type = "Packages",
                    price = 12000.0,
                    description = "4 hours creative photoshoot at gorgeous scenic locations, featuring 20 ultra-high definition edited portraits."
                )
            )
            for (s in defaultServices) {
                shopDao.insertService(s)
            }
        }
    }
}
