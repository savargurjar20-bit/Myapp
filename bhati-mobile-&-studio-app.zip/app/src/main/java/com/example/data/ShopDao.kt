package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface ShopDao {
    // Products
    @Query("SELECT * FROM products ORDER BY timestamp DESC")
    fun getAllProducts(): Flow<List<Product>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProduct(product: Product)

    @Update
    suspend fun updateProduct(product: Product)

    @Delete
    suspend fun deleteProduct(product: Product)

    @Query("DELETE FROM products WHERE id = :id")
    suspend fun deleteProductById(id: Int)

    // Studio Services
    @Query("SELECT * FROM studio_services ORDER BY timestamp DESC")
    fun getAllServices(): Flow<List<StudioService>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertService(service: StudioService)

    @Update
    suspend fun updateService(service: StudioService)

    @Delete
    suspend fun deleteService(service: StudioService)

    @Query("DELETE FROM studio_services WHERE id = :id")
    suspend fun deleteServiceById(id: Int)
}
