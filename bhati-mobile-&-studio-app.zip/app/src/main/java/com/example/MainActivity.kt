package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.example.data.AppDatabase
import com.example.data.ShopRepository
import com.example.ui.MainShopApp
import com.example.ui.ShopViewModel
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)

    val database = AppDatabase.getDatabase(applicationContext)
    val repository = ShopRepository(database.shopDao())
    val viewModel = ShopViewModel(repository)

    enableEdgeToEdge()
    setContent {
      MyApplicationTheme {
        MainShopApp(viewModel = viewModel)
      }
    }
  }
}
