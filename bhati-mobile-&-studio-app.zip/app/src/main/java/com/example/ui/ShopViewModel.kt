package com.example.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.Product
import com.example.data.ShopRepository
import com.example.data.StudioService
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class ShopViewModel(private val repository: ShopRepository) : ViewModel() {

    val products: StateFlow<List<Product>> = repository.allProducts
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    val services: StateFlow<List<StudioService>> = repository.allServices
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    // Admin State
    private val _isAdminLoggedIn = MutableStateFlow(false)
    val isAdminLoggedIn: StateFlow<Boolean> = _isAdminLoggedIn.asStateFlow()

    private val _adminPasswordError = MutableStateFlow<String?>(null)
    val adminPasswordError: StateFlow<String?> = _adminPasswordError.asStateFlow()

    init {
        viewModelScope.launch {
            repository.prepopulateIfEmpty()
        }
    }

    fun loginAdmin(password: String): Boolean {
        return if (password == "bhati123") {
            _isAdminLoggedIn.value = true
            _adminPasswordError.value = null
            true
        } else {
            _adminPasswordError.value = "Incorrect password. Please try again."
            false
        }
    }

    fun logoutAdmin() {
        _isAdminLoggedIn.value = false
        _adminPasswordError.value = null
    }

    // CRUD Product operations
    fun addProduct(name: String, category: String, price: Double, description: String) {
        viewModelScope.launch {
            val product = Product(
                name = name,
                category = category,
                price = price,
                description = description
            )
            repository.insertProduct(product)
        }
    }

    fun updateProduct(id: Int, name: String, category: String, price: Double, description: String) {
        viewModelScope.launch {
            val product = Product(
                id = id,
                name = name,
                category = category,
                price = price,
                description = description
            )
            repository.updateProduct(product)
        }
    }

    fun deleteProduct(product: Product) {
        viewModelScope.launch {
            repository.deleteProduct(product)
        }
    }

    fun deleteProductById(id: Int) {
        viewModelScope.launch {
            repository.deleteProductById(id)
        }
    }

    // CRUD Service operations
    fun addService(name: String, type: String, price: Double, description: String) {
        viewModelScope.launch {
            val service = StudioService(
                name = name,
                type = type,
                price = price,
                description = description
            )
            repository.insertService(service)
        }
    }

    fun updateService(id: Int, name: String, type: String, price: Double, description: String) {
        viewModelScope.launch {
            val service = StudioService(
                id = id,
                name = name,
                type = type,
                price = price,
                description = description
            )
            repository.updateService(service)
        }
    }

    fun deleteService(service: StudioService) {
        viewModelScope.launch {
            repository.deleteService(service)
        }
    }

    fun deleteServiceById(id: Int) {
        viewModelScope.launch {
            repository.deleteServiceById(id)
        }
    }
}
